def imprime_palavra(palavra):
    plv_escondida = []
    list(palavra)
    for i in palavra:
        plv_escondida.append('_ ')
    return plv_escondida